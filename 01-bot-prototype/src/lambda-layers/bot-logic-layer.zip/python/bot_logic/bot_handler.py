import json
import telebot
from bot_logic.tamagochi import tamagochi_repository, tamagochi

BOT_TOKEN = "6668553390:AAETctz7Ap9UeTrmRZema4XM-waR6bT8Dmg"

pet_repo = tamagochi_repository.TamaRepository()

bot = telebot.TeleBot(
    token=BOT_TOKEN,
    threaded=False )

bot.set_my_commands([
    telebot.types.BotCommand("/start", "main menu 2"),
    telebot.types.BotCommand("/hello_telebot", "say hello to Telebot :)"),
    telebot.types.BotCommand("/help", "print usage"),
    telebot.types.BotCommand("/create", "Create new pet")
])


@bot.message_handler(commands=['start'])
def start_command_handler(message):
    username = message.chat.username

    bot.send_message(message.chat.id, f"Hi, {username}. It is start command handler")


@bot.message_handler(commands=['create'])
def create_command_handler(message):
    chat_id = message.chat.id

    owner = message.chat.username
    pet_id = str(chat_id)

    pet_name = "VS"

    pet = tamagochi.Tamagochi(
        tamagochi_id=pet_id,
        name=pet_name,
        owner=owner
    )

    state = pet.get_json_state()
    pet_repo.save_state(owner, pet_id, state)

    # username = message.chat.username
    bot.send_message(message.chat.id, f"Pet {pet_name} created")


@bot.message_handler(content_types='text')
def generic_message_handler(message):
    chat_id = message.chat.id
    # your code goes here
    bot.send_message(chat_id, f"[debug] you say : {message.text}")

    owner = message.chat.username
    pet_id = str(chat_id)
    state = pet_repo.get_state(owner, pet_id)

    if 'name' not in state:
        bot.send_message(chat_id, f"[debug] pet not found")
        return

    bot.send_message(chat_id, f"[debug] {json.dumps(state)}")

    pet = tamagochi.Tamagochi(
        tamagochi_id=pet_id,
        name=state['name'],
        owner=owner
    )
    pet.set_json_state(state)

    pet_replay = pet.process_command(message.text)
    bot.send_message(chat_id, f"{pet.name} > {pet_replay}")

    if pet.is_state_changed():
        state = pet.get_json_state()
        pet_repo.save_state(owner, pet_id, state)


def handle_event(msg):
    json_string = json.dumps(msg)
    update = telebot.types.Update.de_json(json_string)
    bot.process_new_updates([update])
