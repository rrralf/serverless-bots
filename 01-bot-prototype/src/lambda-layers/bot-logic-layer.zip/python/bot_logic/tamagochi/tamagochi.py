class Tamagochi:
    def __init__(self, tamagochi_id, name, owner):
        self.owner = owner
        self.tamagochi_id = tamagochi_id

        self.state_changed = False
        self.age = 0
        self.name = name
        self.hungry = 0

    def is_state_changed(self):
        return self.state_changed

    def get_json_state(self):
        return {
            'name': self.name,
            'age': self.age,
            'hungry': self.hungry
        }

    def set_json_state(self, state):
        self.name = state['name']
        self.age = state['age']
        self.hungry = state['hungry'] if 'hungry' in state else 0

    def live(self):
        self.state_changed = True
        self.age = self.age+1
        self.hungry = self.hungry + 1

    def feed(self):
        self.state_changed = True
        self.hungry = self.hungry - 1 if self.hungry > 1 else 0

    def get_state(self):
        return f"{self.name} >> age: {self.age}; hungry: {self.hungry}"


    def process_command(self, command):
        if command == "eat":
            self.feed()
            return "feeded"
        elif command == "live":
            self.live()
            return "lived one day"
        else:
            return "unknown command"