import json
import boto3

dynamodb = boto3.client('dynamodb')

class TamaRepository:
    def __init__(self):
        self.table_name = "SampleTamaState"

    def save_state(self, owner : str, pet_id : str, data):
        dynamodb.put_item(
            TableName=self.table_name,
            Item = {
                'PK': {'S': owner },
                'SK': {'S': pet_id },
                'State': {'S': json.dumps(data) }
            })

    def get_state(self, owner, pet_id):
        state = dynamodb.get_item(
            TableName=self.table_name,
            Key={
                'PK': {'S': owner},
                'SK': {'S': pet_id}
            })

        return json.loads(state["Item"]["State"]["S"]) if 'Item' in state else {}



